CS 499 Milestone Three — Enhancement Two: Algorithms and Data Structures
Student: Richard T. Walker
Artifact: CS 320 Contact Service

This archive contains:

  original/SNHU_CS320-main
      Unmodified CS 320 Contact Service source and Project Two write-up.

  enhanced/ContactService
      CS 499 enhanced source with last-name and phone secondary indexes,
      sorted listing, stricter validation, JUnit tests, a benchmark harness,
      README, enhancement notes, and recorded timings.

Submit the narrative Word document separately:
  CS 499 Milestone Three Narrative_Walker Richard.docx
