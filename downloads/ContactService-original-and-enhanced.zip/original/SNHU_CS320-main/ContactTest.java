/**
 * Author: Richard T. Walker
 * Course: CS320 
 * File: ContactTest.java
 * Description: Unit tests for the Contact class to ensure proper field assignment and validation.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    // Tests creation of a valid contact object
    @Test
    public void shouldCreateValidContact() {
        Contact testEntry = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        assertEquals("ID100", testEntry.getContactId());
        assertEquals("Alice", testEntry.getFirstName());
        assertEquals("Smith", testEntry.getLastName());
        assertEquals("9876543210", testEntry.getPhone());
        assertEquals("742 Evergreen Terrace", testEntry.getAddress());
    }

    // Ensures that null or too-long IDs cause errors
    @Test
    public void shouldThrowErrorForInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID1234567890", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
    }

    // Tests updating the first name with valid and invalid values
    @Test
    public void shouldUpdateFirstNameSafely() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setFirstName("Eve");
        assertEquals("Eve", person.getFirstName());

        assertThrows(IllegalArgumentException.class, () -> person.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> person.setFirstName("OverlyLongNameHere"));
    }

    // Tests updating the last name with valid and invalid values
    @Test
    public void shouldUpdateLastNameSafely() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setLastName("Williams");
        assertEquals("Williams", person.getLastName());

        assertThrows(IllegalArgumentException.class, () -> person.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> person.setLastName("ExtraLongLastName"));
    }

    // Tests updating the phone number with valid and invalid values
    @Test
    public void shouldUpdatePhoneNumberIfValid() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setPhone("0123456789");
        assertEquals("0123456789", person.getPhone());

        assertThrows(IllegalArgumentException.class, () -> person.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> person.setPhone("123"));
    }

    // Tests updating the address with valid and invalid values
    @Test
    public void shouldUpdateAddressWithValidInput() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setAddress("221B Baker Street");
        assertEquals("221B Baker Street", person.getAddress());

        assertThrows(IllegalArgumentException.class, () -> person.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> person.setAddress("1234567890 Some Very Long Address That Exceeds Thirty Characters"));
    }
}
