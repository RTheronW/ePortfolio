# SNHU_CS320

## How can I ensure that my code, program, or software is functional and secure?
- I can ensure my code is functional and secure by writing unit tests that validate the behavior of individual components and by performing code reviews to identify potential logic flaws or security vulnerabilities. Using established coding standards and practices, such as input validation and exception handling, also helps prevent common security issues like injection attacks or data leaks. Additionally, leveraging tools like static code analyzers and running my code through security-focused testing ensures that vulnerabilities are identified early in the development cycle.

## How do I interpret user needs and incorporate them into a program?
- I interpret user needs by carefully reviewing requirements documentation, asking clarifying questions when necessary, and translating those needs into clear technical specifications. I break down user stories or requirements into smaller functional tasks and ensure that the software’s logic and features align with the intended outcomes. Throughout development, I verify that my implementation meets these needs by writing tests based on those requirements and validating them against expected behavior.

## How do I approach designing software?
- I approach designing software by first understanding the problem the software is meant to solve and then creating a plan that outlines the system’s key components and how they will interact. I prioritize modular design, ensuring that each part of the software has a single responsibility and can be tested independently. I often start with pseudocode or diagrams to map out the logic before writing actual code. This helps ensure the design is clear, maintainable, and adaptable to future changes.
