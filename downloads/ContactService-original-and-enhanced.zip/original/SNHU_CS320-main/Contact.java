/**
 * Author: Richard T. Walker
 * Course: CS320
 * File: Contact.java
 * Description: Represents a contact with basic personal details and validation constraints.
 */

public class Contact {
    private final String id;
    private String first;
    private String last;
    private String mobile;
    private String homeAddress;

    // Constructor that validates all required fields before assigning them
    public Contact(String id, String first, String last, String mobile, String homeAddress) {
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Contact ID must be non-null and no more than 10 characters.");
        }
        if (first == null || first.length() > 10) {
            throw new IllegalArgumentException("First name must be non-null and under 11 characters.");
        }
        if (last == null || last.length() > 10) {
            throw new IllegalArgumentException("Last name must be non-null and under 11 characters.");
        }
        if (mobile == null || mobile.length() != 10) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
        }
        if (homeAddress == null || homeAddress.length() > 30) {
            throw new IllegalArgumentException("Address must not exceed 30 characters.");
        }

        this.id = id;
        this.first = first;
        this.last = last;
        this.mobile = mobile;
        this.homeAddress = homeAddress;
    }

    // Read-only contact ID
    public String getContactId() {
        return id;
    }

    // Getter and setter for first name with validation
    public String getFirstName() {
        return first;
    }

    public void setFirstName(String newFirst) {
        if (newFirst == null || newFirst.length() > 10) {
            throw new IllegalArgumentException("Invalid input for first name.");
        }
        this.first = newFirst;
    }

    // Getter and setter for last name with validation
    public String getLastName() {
        return last;
    }

    public void setLastName(String newLast) {
        if (newLast == null || newLast.length() > 10) {
            throw new IllegalArgumentException("Invalid input for last name.");
        }
        this.last = newLast;
    }

    // Getter and setter for phone number with validation
    public String getPhone() {
        return mobile;
    }

    public void setPhone(String newMobile) {
        if (newMobile == null || newMobile.length() != 10) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }
        this.mobile = newMobile;
    }

    // Getter and setter for address with validation
    public String getAddress() {
        return homeAddress;
    }

    public void setAddress(String newAddress) {
        if (newAddress == null || newAddress.length() > 30) {
            throw new IllegalArgumentException("Address must be 30 characters or fewer.");
        }
        this.homeAddress = newAddress;
    }
}
