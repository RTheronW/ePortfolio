/**
 * Author: Richard T. Walker
 * Course: CS320 
 * File: ContactServiceTest.java
 * Description: This class tests the functionality of the ContactService class
 *              by verifying adding, deleting, and updating contact records.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    // Test that a new contact can be successfully registered and retrieved
    @Test
    public void shouldSuccessfullyRegisterContact() {
        ContactService directory = new ContactService();
        Contact entry = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(entry);
        assertEquals(entry, directory.findContact("A001"));
    }

    // Test that duplicate contact IDs are not allowed
    @Test
    public void shouldPreventDuplicateContactId() {
        ContactService directory = new ContactService();
        Contact one = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        Contact duplicate = new Contact("A001", "Ethan", "Wells", "7894561230", "12 Baker Street");

        directory.registerContact(one);
        assertThrows(IllegalArgumentException.class, () -> directory.registerContact(duplicate));
    }

    // Test that a contact can be successfully removed
    @Test
    public void shouldRemoveContactFromDirectory() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.removeContact("A001");
        assertNull(directory.findContact("A001"));
    }

    // Test that the first name of a contact can be updated
    @Test
    public void shouldModifyFirstNameInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyFirstName("A001", "Chloe");
        assertEquals("Chloe", user.getFirstName());
    }

    // Test that the last name of a contact can be updated
    @Test
    public void shouldModifyLastNameInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyLastName("A001", "Brooks");
        assertEquals("Brooks", user.getLastName());
    }

    // Test that the phone number of a contact can be updated
    @Test
    public void shouldModifyPhoneInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyPhone("A001", "1231231234");
        assertEquals("1231231234", user.getPhone());
    }

    // Test that the address of a contact can be updated
    @Test
    public void shouldModifyAddressInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyAddress("A001", "742 Pine St");
        assertEquals("742 Pine St", user.getAddress());
    }
}
