/**
 * Author: Richard T. Walker
 * Course: CS320 
 * File: ContactService.java
 * Description: Manages a collection of contacts with operations to add, remove, and update them.
 */

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> directory;

    // Constructor initializes an in-memory contact directory
    public ContactService() {
        directory = new HashMap<>();
    }

    // Adds a contact if the ID is unique
    public void registerContact(Contact newContact) {
        if (newContact == null || directory.containsKey(newContact.getContactId())) {
            throw new IllegalArgumentException("Contact is invalid or already exists.");
        }
        directory.put(newContact.getContactId(), newContact);
    }

    // Deletes a contact from the directory by ID
    public void removeContact(String id) {
        if (!directory.containsKey(id)) {
            throw new IllegalArgumentException("No contact found for the provided ID.");
        }
        directory.remove(id);
    }

    // Updates the first name of a contact
    public void modifyFirstName(String id, String updatedFirst) {
        Contact person = directory.get(id);
        if (person != null) {
            person.setFirstName(updatedFirst);
        } else {
            throw new IllegalArgumentException("ID not found in the contact list.");
        }
    }

    // Updates the last name of a contact
    public void modifyLastName(String id, String updatedLast) {
        Contact person = directory.get(id);
        if (person != null) {
            person.setLastName(updatedLast);
        } else {
            throw new IllegalArgumentException("ID not found in the contact list.");
        }
    }

    // Updates the phone number of a contact
    public void modifyPhone(String id, String updatedMobile) {
        Contact person = directory.get(id);
        if (person != null) {
            person.setPhone(updatedMobile);
        } else {
            throw new IllegalArgumentException("ID not found in the contact list.");
        }
    }

    // Updates the address of a contact
    public void modifyAddress(String id, String updatedAddress) {
        Contact person = directory.get(id);
        if (person != null) {
            person.setAddress(updatedAddress);
        } else {
            throw new IllegalArgumentException("ID not found in the contact list.");
        }
    }

    // Retrieves a contact by ID
    public Contact findContact(String id) {
        return directory.get(id);
    }
}
