/**
 * Author: Richard T. Walker
 * Course: CS 499 Milestone Three (original work: CS 320)
 * File: ContactTest.java
 * Description: Unit tests for Contact construction, setters, blank-field
 *              rejection, and ten-digit phone validation.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void shouldCreateValidContact() {
        Contact testEntry = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        assertEquals("ID100", testEntry.getContactId());
        assertEquals("Alice", testEntry.getFirstName());
        assertEquals("Smith", testEntry.getLastName());
        assertEquals("9876543210", testEntry.getPhone());
        assertEquals("742 Evergreen Terrace", testEntry.getAddress());
    }

    @Test
    public void shouldThrowErrorForInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID1234567890", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
    }

    @Test
    public void shouldRejectBlankContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("   ", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        });
    }

    @Test
    public void shouldUpdateFirstNameSafely() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setFirstName("Eve");
        assertEquals("Eve", person.getFirstName());

        assertThrows(IllegalArgumentException.class, () -> person.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> person.setFirstName("OverlyLongNameHere"));
        assertThrows(IllegalArgumentException.class, () -> person.setFirstName(""));
    }

    @Test
    public void shouldUpdateLastNameSafely() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setLastName("Williams");
        assertEquals("Williams", person.getLastName());

        assertThrows(IllegalArgumentException.class, () -> person.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> person.setLastName("ExtraLongLastName"));
        assertThrows(IllegalArgumentException.class, () -> person.setLastName("   "));
    }

    @Test
    public void shouldUpdatePhoneNumberIfValid() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setPhone("0123456789");
        assertEquals("0123456789", person.getPhone());

        assertThrows(IllegalArgumentException.class, () -> person.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> person.setPhone("123"));
    }

    @Test
    public void shouldRejectPhoneThatIsNotTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID100", "Alice", "Smith", "ABCDEFGHIJ", "742 Evergreen Terrace");
        });
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        assertThrows(IllegalArgumentException.class, () -> person.setPhone("12AB56CD90"));
    }

    @Test
    public void shouldUpdateAddressWithValidInput() {
        Contact person = new Contact("ID100", "Alice", "Smith", "9876543210", "742 Evergreen Terrace");
        person.setAddress("221B Baker Street");
        assertEquals("221B Baker Street", person.getAddress());

        assertThrows(IllegalArgumentException.class, () -> person.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> person.setAddress(
                "1234567890 Some Very Long Address That Exceeds Thirty Characters"));
        assertThrows(IllegalArgumentException.class, () -> person.setAddress(""));
    }
}
