/**
 * Author: Richard T. Walker
 * Course: CS 499 Milestone Three (original work: CS 320)
 * File: ContactServiceTest.java
 * Description: Tests id-map operations plus last-name and phone index
 *              maintenance, prefix search, sorted listing, and missing-id
 *              updates.
 */

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void shouldSuccessfullyRegisterContact() {
        ContactService directory = new ContactService();
        Contact entry = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(entry);
        assertEquals(entry, directory.findContact("A001"));
    }

    @Test
    public void shouldPreventDuplicateContactId() {
        ContactService directory = new ContactService();
        Contact one = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        Contact duplicate = new Contact("A001", "Ethan", "Wells", "7894561230", "12 Baker Street");

        directory.registerContact(one);
        assertThrows(IllegalArgumentException.class, () -> directory.registerContact(duplicate));
    }

    @Test
    public void shouldRemoveContactFromDirectory() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.removeContact("A001");
        assertNull(directory.findContact("A001"));
    }

    @Test
    public void shouldNotReturnDeletedContactInLastNameSearch() {
        ContactService directory = seededDirectory();
        directory.removeContact("A001");
        List<Contact> found = directory.searchByLastName("Clark");
        assertTrue(found.isEmpty());
        assertTrue(directory.searchByPhone("3216549870").isEmpty());
    }

    @Test
    public void shouldModifyFirstNameInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyFirstName("A001", "Chloe");
        assertEquals("Chloe", user.getFirstName());
    }

    @Test
    public void shouldModifyLastNameInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyLastName("A001", "Brooks");
        assertEquals("Brooks", user.getLastName());
    }

    @Test
    public void shouldReindexAfterLastNameChange() {
        ContactService directory = seededDirectory();
        directory.modifyLastName("A001", "Brooks");
        assertTrue(directory.searchByLastName("Clark").isEmpty());
        List<Contact> brooks = directory.searchByLastName("Brooks");
        assertEquals(2, brooks.size());
        assertTrue(brooks.stream().anyMatch(c -> "A001".equals(c.getContactId())));
    }

    @Test
    public void shouldModifyPhoneInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyPhone("A001", "1231231234");
        assertEquals("1231231234", user.getPhone());
    }

    @Test
    public void shouldReindexAfterPhoneChange() {
        ContactService directory = seededDirectory();
        directory.modifyPhone("A001", "1111111111");
        assertTrue(directory.searchByPhone("3216549870").isEmpty());
        assertEquals("A001", directory.searchByPhone("1111111111").get(0).getContactId());
    }

    @Test
    public void shouldModifyAddressInContact() {
        ContactService directory = new ContactService();
        Contact user = new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive");
        directory.registerContact(user);
        directory.modifyAddress("A001", "742 Pine St");
        assertEquals("742 Pine St", user.getAddress());
    }

    @Test
    public void shouldRejectUpdatesForMissingId() {
        ContactService directory = new ContactService();
        assertThrows(IllegalArgumentException.class,
                () -> directory.modifyFirstName("MISSING", "Chloe"));
        assertThrows(IllegalArgumentException.class,
                () -> directory.modifyLastName("MISSING", "Brooks"));
        assertThrows(IllegalArgumentException.class,
                () -> directory.modifyPhone("MISSING", "1231231234"));
        assertThrows(IllegalArgumentException.class,
                () -> directory.modifyAddress("MISSING", "742 Pine St"));
        assertThrows(IllegalArgumentException.class,
                () -> directory.removeContact("MISSING"));
    }

    @Test
    public void shouldFindContactsByLastNameAndPrefix() {
        ContactService directory = seededDirectory();
        List<Contact> clarks = directory.searchByLastName("clark");
        assertEquals(1, clarks.size());
        assertEquals("A001", clarks.get(0).getContactId());

        List<Contact> prefixB = directory.searchByLastNamePrefix("Br");
        assertEquals(1, prefixB.size());
        assertEquals("A002", prefixB.get(0).getContactId());

        List<Contact> prefixNone = directory.searchByLastNamePrefix("Zz");
        assertTrue(prefixNone.isEmpty());
        assertTrue(directory.searchByLastName("").isEmpty());
    }

    @Test
    public void shouldListContactsSortedByName() {
        ContactService directory = seededDirectory();
        List<Contact> sorted = directory.listAllSortedByName();
        assertEquals(3, sorted.size());
        assertEquals("Brooks", sorted.get(0).getLastName());
        assertEquals("Clark", sorted.get(1).getLastName());
        assertEquals("Wells", sorted.get(2).getLastName());
    }

    @Test
    public void shouldFindContactByPhone() {
        ContactService directory = seededDirectory();
        List<Contact> found = directory.searchByPhone("7894561230");
        assertEquals(1, found.size());
        assertEquals("A002", found.get(0).getContactId());
    }

    private ContactService seededDirectory() {
        ContactService directory = new ContactService();
        directory.registerContact(new Contact("A001", "Emily", "Clark", "3216549870", "5 Oakridge Drive"));
        directory.registerContact(new Contact("A002", "Ethan", "Brooks", "7894561230", "12 Baker Street"));
        directory.registerContact(new Contact("A003", "Ava", "Wells", "5551234567", "9 Pine Court"));
        return directory;
    }
}
