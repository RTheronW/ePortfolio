# Benchmark results — Artifact Two

Author: Richard T. Walker  
Course: CS 499 Milestone Three  
Host: OpenJDK 21, single-process Java main (`ContactServiceBenchmark`)

## Setup

- 8,000 generated contacts
- 20 shared last names (about 400 contacts per last-name bucket)
- Unique ten-digit phones
- 50 warmup queries, then 400 timed queries per strategy

The linear scan is the strategy the original service would have needed for a name search. It is package-visible only so the benchmark can call it. Production name search uses the index.

## Results

| Strategy | Big-O | Total for 400 queries | Approx. per query |
| --- | --- | --- | --- |
| Linear last-name scan | O(n) | 160.628 ms | 401,570 ns |
| HashMap id lookup | O(1) avg | 0.399 ms | 996 ns |
| Last-name index lookup | O(1) avg + O(k) | 0.860 ms | 2,150 ns |
| Last-name prefix (walk keys) | O(b + k) | 3.422 ms | 8,555 ns |
| Phone index lookup | O(1) avg + O(k) | 3.122 ms | 7,804 ns |

Last-name index vs linear scan: about **187×** faster on this data set.  
Id lookup vs linear scan: about **403×** faster.

## Space trade-off

The two secondary indexes add O(n) extra references: one list entry per contact in the last-name map and one in the phone map.

On this run:

- directory size: 8,000
- last-name buckets: 20
- phone buckets: 8,000 (phones are unique)

The last-name index is cheap in key count because names repeat. The phone index has one key per contact, so it costs more memory for the same O(1) average lookup. That is acceptable here because a phone query is an expected access path and 8,000 extra map entries is still small for an in-memory directory.

## What the numbers mean

Id lookup stays the fastest operation. That is why the original HashMap was kept. The last-name index closes the gap for the access path the original design did not support. Prefix search is slower than exact-name lookup because it walks the last-name keys; with 20 keys that walk is still far cheaper than scanning 8,000 contacts. A `TreeMap` on last name would make prefix search a range query. It was not used because the approved plan specified HashMap indexes and, with only tens of distinct names, walking those keys is already cheap.
