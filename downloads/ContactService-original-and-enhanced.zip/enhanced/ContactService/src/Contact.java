/**
 * Author: Richard T. Walker
 * Course: CS 499 Milestone Three (original work: CS 320)
 * File: Contact.java
 * Description: In-memory contact record. Validation is centralized so the
 *              constructor and setters enforce the same rules: non-blank
 *              identifiers and names, a ten-digit phone, and an address of
 *              at most thirty characters. The contact id is immutable.
 */
public class Contact {
    private final String id;
    private String first;
    private String last;
    private String mobile;
    private String homeAddress;

    public Contact(String id, String first, String last, String mobile, String homeAddress) {
        this.id = requireText(id, 10, "Contact ID");
        this.first = requireText(first, 10, "First name");
        this.last = requireText(last, 10, "Last name");
        this.mobile = requirePhone(mobile);
        this.homeAddress = requireAddress(homeAddress);
    }

    public String getContactId() {
        return id;
    }

    public String getFirstName() {
        return first;
    }

    public void setFirstName(String newFirst) {
        this.first = requireText(newFirst, 10, "First name");
    }

    public String getLastName() {
        return last;
    }

    public void setLastName(String newLast) {
        this.last = requireText(newLast, 10, "Last name");
    }

    public String getPhone() {
        return mobile;
    }

    public void setPhone(String newMobile) {
        this.mobile = requirePhone(newMobile);
    }

    public String getAddress() {
        return homeAddress;
    }

    public void setAddress(String newAddress) {
        this.homeAddress = requireAddress(newAddress);
    }

    /**
     * Rejects null, blank, and over-length text. Blank includes empty and
     * whitespace-only strings so an id or name cannot slip through as " ".
     */
    static String requireText(String value, int maxLen, String field) {
        if (value == null || value.isBlank() || value.length() > maxLen) {
            throw new IllegalArgumentException(
                    field + " must be non-blank and at most " + maxLen + " characters.");
        }
        return value;
    }

    /**
     * Phone must be exactly ten ASCII digits. Length-only checks would accept
     * "ABCDEFGHIJ".
     */
    static String requirePhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
        }
        return phone;
    }

    static String requireAddress(String address) {
        if (address == null || address.isBlank() || address.length() > 30) {
            throw new IllegalArgumentException(
                    "Address must be non-blank and at most 30 characters.");
        }
        return address;
    }
}
