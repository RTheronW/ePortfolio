/**
 * Author: Richard T. Walker
 * Course: CS 499 Milestone Three
 * File: ContactServiceBenchmark.java
 * Description: Measures linear last-name scan, HashMap id lookup, last-name
 *              index lookup, and prefix search on a generated directory.
 *              Not a JUnit test. Run: java ContactServiceBenchmark
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ContactServiceBenchmark {
    private static final int DIRECTORY_SIZE = 8000;
    private static final int ROUNDS = 400;
    private static final String[] LAST_NAMES = {
            "Smith", "Clark", "Brooks", "Nguyen", "Patel",
            "Garcia", "Walker", "Brown", "Davis", "Wilson",
            "Moore", "Taylor", "Anderson", "Thomas", "Jackson",
            "White", "Harris", "Martin", "Thompson", "Lee"
    };

    public static void main(String[] args) {
        ContactService service = new ContactService();
        List<String> ids = new ArrayList<>(DIRECTORY_SIZE);
        for (int i = 0; i < DIRECTORY_SIZE; i++) {
            String id = String.format(Locale.ROOT, "C%09d", i);
            String first = "First" + (i % 90);
            if (first.length() > 10) {
                first = first.substring(0, 10);
            }
            String last = LAST_NAMES[i % LAST_NAMES.length];
            String phone = String.format(Locale.ROOT, "%010d", 2_000_000_000L + i);
            service.registerContact(new Contact(id, first, last, phone, "100 Main Street"));
            ids.add(id);
        }

        // Warm the JIT so the timed loops are not dominated by first-call cost.
        for (int i = 0; i < 50; i++) {
            service.findContact(ids.get(i));
            service.searchByLastName("Smith");
            service.scanByLastName("Smith");
            service.searchByLastNamePrefix("Sm");
        }

        long scanNs = time(() -> {
            for (int i = 0; i < ROUNDS; i++) {
                service.scanByLastName(LAST_NAMES[i % LAST_NAMES.length]);
            }
        });
        long idNs = time(() -> {
            for (int i = 0; i < ROUNDS; i++) {
                service.findContact(ids.get((i * 17) % DIRECTORY_SIZE));
            }
        });
        long lastNs = time(() -> {
            for (int i = 0; i < ROUNDS; i++) {
                service.searchByLastName(LAST_NAMES[i % LAST_NAMES.length]);
            }
        });
        long prefixNs = time(() -> {
            for (int i = 0; i < ROUNDS; i++) {
                service.searchByLastNamePrefix("S");
            }
        });
        long phoneNs = time(() -> {
            for (int i = 0; i < ROUNDS; i++) {
                String phone = String.format(Locale.ROOT, "%010d",
                        2_000_000_000L + ((i * 31) % DIRECTORY_SIZE));
                service.searchByPhone(phone);
            }
        });

        System.out.println("ContactService benchmark");
        System.out.println("Directory size: " + service.size());
        System.out.println("Last-name buckets: " + service.lastNameBucketCount());
        System.out.println("Phone buckets: " + service.phoneBucketCount());
        System.out.println("Rounds per strategy: " + ROUNDS);
        System.out.println();
        printTiming("Linear last-name scan      O(n) per query", scanNs);
        printTiming("HashMap id lookup          O(1) avg", idNs);
        printTiming("Last-name index lookup     O(1) avg + O(k)", lastNs);
        printTiming("Last-name prefix (key walk) O(b + k)", prefixNs);
        printTiming("Phone index lookup         O(1) avg + O(k)", phoneNs);
        System.out.println();
        System.out.println("Extra index memory: two HashMaps plus one list entry");
        System.out.println("per contact in each index, so O(n) additional references.");
        System.out.println("With " + service.size() + " contacts there are "
                + service.lastNameBucketCount() + " last-name keys and "
                + service.phoneBucketCount() + " phone keys.");
        System.out.printf(Locale.ROOT,
                "Index vs scan speedup (last name): %.1fx%n",
                (double) scanNs / (double) lastNs);
        System.out.printf(Locale.ROOT,
                "Id lookup vs last-name scan:       %.1fx%n",
                (double) scanNs / (double) idNs);
    }

    private static long time(Runnable work) {
        long start = System.nanoTime();
        work.run();
        return System.nanoTime() - start;
    }

    private static void printTiming(String label, long nanos) {
        double ms = nanos / 1_000_000.0;
        long perQueryNs = nanos / ROUNDS;
        System.out.printf(Locale.ROOT, "%-42s  total %7.3f ms   per query ~%d ns%n",
                label, ms, perQueryNs);
        // Keep TimeUnit import used so the file stays self-explanatory.
        if (TimeUnit.NANOSECONDS.toMillis(nanos) < 0) {
            System.out.println();
        }
    }
}
