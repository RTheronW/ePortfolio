/**
 * Author: Richard T. Walker
 * Course: CS 499 Milestone Three (original work: CS 320)
 * File: ContactService.java
 * Description: In-memory contact directory. The primary store is a HashMap
 *              keyed by contact id (average O(1) add, find, update, delete).
 *              Secondary HashMaps index last name and phone so name and phone
 *              searches do not scan the full directory. Sorted listing copies
 *              the values and sorts in O(n log n). Indexes are updated on
 *              every register, remove, last-name change, and phone change.
 *
 * Complexity:
 *   registerContact / removeContact / findContact / modify* by id : O(1) avg
 *   searchByLastName / searchByPhone                               : O(1) avg + O(k) copy
 *   searchByLastNamePrefix                                         : O(b + k) where b is
 *                                                                     the number of last-name
 *                                                                     buckets and k is matches
 *   listAllSortedByName                                            : O(n log n)
 *   Extra memory for the two indexes                               : O(n)
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> directory;
    private final Map<String, List<Contact>> byLastName;
    private final Map<String, List<Contact>> byPhone;

    public ContactService() {
        directory = new HashMap<>();
        byLastName = new HashMap<>();
        byPhone = new HashMap<>();
    }

    /**
     * Adds a contact to the id map and both secondary indexes.
     * Rejects a null contact or a duplicate id. Average O(1).
     */
    public void registerContact(Contact newContact) {
        if (newContact == null || directory.containsKey(newContact.getContactId())) {
            throw new IllegalArgumentException("Contact is invalid or already exists.");
        }
        directory.put(newContact.getContactId(), newContact);
        indexLastName(newContact);
        indexPhone(newContact);
    }

    /**
     * Removes a contact from the id map and both indexes. Average O(1).
     */
    public void removeContact(String id) {
        Contact person = requireContact(id);
        directory.remove(id);
        unindexLastName(person);
        unindexPhone(person);
    }

    public void modifyFirstName(String id, String updatedFirst) {
        requireContact(id).setFirstName(updatedFirst);
    }

    /**
     * Updates last name and moves the contact to the matching index bucket.
     * Average O(1) plus the cost of list remove on the old bucket.
     */
    public void modifyLastName(String id, String updatedLast) {
        Contact person = requireContact(id);
        unindexLastName(person);
        person.setLastName(updatedLast);
        indexLastName(person);
    }

    /**
     * Updates phone and moves the contact to the matching phone-index bucket.
     */
    public void modifyPhone(String id, String updatedMobile) {
        Contact person = requireContact(id);
        unindexPhone(person);
        person.setPhone(updatedMobile);
        indexPhone(person);
    }

    public void modifyAddress(String id, String updatedAddress) {
        requireContact(id).setAddress(updatedAddress);
    }

    /**
     * Exact id lookup. Average O(1). Returns null when the id is missing,
     * matching the original CS 320 contract for read operations.
     */
    public Contact findContact(String id) {
        return directory.get(id);
    }

    /**
     * Exact last-name lookup using the secondary index. Average O(1) to
     * reach the bucket, then O(k) to copy the matching contacts.
     */
    public List<Contact> searchByLastName(String lastName) {
        if (lastName == null || lastName.isBlank()) {
            return Collections.emptyList();
        }
        List<Contact> bucket = byLastName.get(normalize(lastName));
        if (bucket == null || bucket.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<>(bucket));
    }

    /**
     * Prefix last-name search. Walks index keys rather than every contact.
     * O(b + k) where b is the number of distinct last names.
     */
    public List<Contact> searchByLastNamePrefix(String prefix) {
        if (prefix == null || prefix.isBlank()) {
            return Collections.emptyList();
        }
        String key = normalize(prefix);
        List<Contact> results = new ArrayList<>();
        for (Map.Entry<String, List<Contact>> entry : byLastName.entrySet()) {
            if (entry.getKey().startsWith(key)) {
                results.addAll(entry.getValue());
            }
        }
        return Collections.unmodifiableList(results);
    }

    /**
     * Exact phone lookup using the phone index. Average O(1) + O(k) copy.
     */
    public List<Contact> searchByPhone(String phone) {
        if (phone == null || phone.isBlank()) {
            return Collections.emptyList();
        }
        List<Contact> bucket = byPhone.get(phone);
        if (bucket == null || bucket.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<>(bucket));
    }

    /**
     * Returns a new list sorted by last name, then first name.
     * Does not mutate the directory. O(n log n).
     */
    public List<Contact> listAllSortedByName() {
        List<Contact> snapshot = new ArrayList<>(directory.values());
        snapshot.sort(Comparator
                .comparing((Contact c) -> normalize(c.getLastName()))
                .thenComparing(c -> normalize(c.getFirstName()))
                .thenComparing(Contact::getContactId));
        return Collections.unmodifiableList(snapshot);
    }

    public int size() {
        return directory.size();
    }

    /** Distinct last-name buckets. Used by the benchmark for space cost. */
    int lastNameBucketCount() {
        return byLastName.size();
    }

    /** Distinct phone buckets. Used by the benchmark for space cost. */
    int phoneBucketCount() {
        return byPhone.size();
    }

    /**
     * Linear scan used only by the benchmark so the index can be compared
     * against the strategy the original service would have needed.
     */
    List<Contact> scanByLastName(String lastName) {
        String key = normalize(lastName);
        List<Contact> results = new ArrayList<>();
        for (Contact contact : directory.values()) {
            if (normalize(contact.getLastName()).equals(key)) {
                results.add(contact);
            }
        }
        return results;
    }

    private Contact requireContact(String id) {
        Contact person = directory.get(id);
        if (person == null) {
            throw new IllegalArgumentException("ID not found in the contact list.");
        }
        return person;
    }

    private void indexLastName(Contact contact) {
        byLastName.computeIfAbsent(normalize(contact.getLastName()), k -> new ArrayList<>())
                .add(contact);
    }

    private void unindexLastName(Contact contact) {
        String key = normalize(contact.getLastName());
        List<Contact> bucket = byLastName.get(key);
        if (bucket == null) {
            return;
        }
        bucket.remove(contact);
        if (bucket.isEmpty()) {
            byLastName.remove(key);
        }
    }

    private void indexPhone(Contact contact) {
        byPhone.computeIfAbsent(contact.getPhone(), k -> new ArrayList<>()).add(contact);
    }

    private void unindexPhone(Contact contact) {
        String key = contact.getPhone();
        List<Contact> bucket = byPhone.get(key);
        if (bucket == null) {
            return;
        }
        bucket.remove(contact);
        if (bucket.isEmpty()) {
            byPhone.remove(key);
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }
}
