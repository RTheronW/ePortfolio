# CS 499 Artifact Two — Contact Service (enhanced)

Author: Richard T. Walker  
Original course: CS 320 (June 2025)  
Enhancement: CS 499 Milestone Three, Algorithms and Data Structures

## What this project is

An in-memory contact directory. `Contact` holds id, first name, last name, phone, and address. `ContactService` adds, finds, updates, and deletes contacts.

The CS 320 version already stored contacts in a `HashMap` keyed by id, so exact-id operations were average O(1). It had no second access path, no sorted listing, and no measured comparison of search strategies. Phone values were checked for length, not digits, and blank ids or names were accepted.

## What changed in CS 499

- Kept `Map<String, Contact> directory` for O(1) average id operations.
- Added a last-name secondary index and a phone secondary index.
- Added `searchByLastName`, `searchByLastNamePrefix`, `searchByPhone`, and `listAllSortedByName`.
- Update and delete keep both indexes in sync, including after a last-name or phone change.
- Validation now rejects blank ids, names, and addresses, and requires a ten-digit phone.
- JUnit 5 tests cover the original id path plus index maintenance, prefix search, sorted order, missing-id updates, and the stricter validation.
- `ContactServiceBenchmark` inserts 8,000 generated contacts and times linear scan, HashMap id lookup, last-name index lookup, prefix search, and phone index lookup.

## How to compile and test

Requires Java 17 or later and the JUnit Platform Console Standalone jar.

```bash
javac -d out src/*.java
javac -d out -cp "out:junit-platform-console-standalone.jar" test/*.java
java -jar junit-platform-console-standalone.jar execute --class-path out --scan-class-path
java -cp out ContactServiceBenchmark
```

## Complexity

| Operation | Structure | Average cost |
| --- | --- | --- |
| Add / find / update / delete by id | HashMap `directory` | O(1) |
| Search by last name or phone | secondary HashMap + list copy | O(1) + O(k) matches |
| Search by last-name prefix | walk last-name keys | O(b + k) distinct names + matches |
| List sorted by name | copy + sort | O(n log n) |
| Extra memory for both indexes | two maps + list entries | O(n) |

Exact-id lookup stays the fastest path. The last-name index is the right tool when the caller has a name instead of an id. A linear scan is only kept as a benchmark baseline.

## Files

- `src/Contact.java` — model and shared validation
- `src/ContactService.java` — directory plus indexes
- `src/ContactServiceBenchmark.java` — timing harness
- `test/ContactTest.java`
- `test/ContactServiceTest.java`
- `ENHANCEMENT_NOTES.md` — code-review findings mapped to files
- `BENCHMARK.md` — recorded timings
