# Enhancement notes — Artifact Two

Author: Richard T. Walker  
Course: CS 499 Milestone Three  
Artifact: CS 320 Contact Service

This file maps each code-review finding to the change that closed it.

1. Single access path (id only) — `ContactService.byLastName`, `byPhone`, `searchByLastName`, `searchByPhone`
2. No prefix search — `searchByLastNamePrefix`
3. No sorted listing — `listAllSortedByName`
4. Indexes would go stale on delete — `removeContact` unindexes last name and phone
5. Last-name update would leave the old bucket — `modifyLastName` unindexes, then reindexes
6. Phone update would leave the old bucket — `modifyPhone` unindexes, then reindexes
7. Repeated modify methods with inconsistent missing-id handling — private `requireContact`
8. Phone checked for length, not digits — `Contact.requirePhone`
9. Blank ids and names accepted — `Contact.requireText`
10. Tests never left the id path — new tests in `ContactTest` and `ContactServiceTest`
11. No measured comparison of strategies — `ContactServiceBenchmark` and `BENCHMARK.md`
12. Headers did not state complexity — Big-O comments on `ContactService`
