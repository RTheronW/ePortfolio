# CRUD operations for Animal collection in MongoDB
from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    """
    CRUD operations for the 'animals' collection in the 'aac' MongoDB database.
    Supports Create, Read, Update, and Delete (full CRUD) functionality.
    """
   
    def __init__(self, username=None, password=None):
        """
        Initializes connection to MongoDB using authenticated user credentials.
        Uses authSource=admin since the user was created in the admin database.
        """
        USER = username or 'aacuser'
        PASS = password or 'eoGU&4un*30'  
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
   
        try:
            self.client = MongoClient(
                f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin'
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]
            self.client.admin.command('ping')  # Verify connection
            print("MongoDB connection established successfully")
        except Exception as e:
            raise Exception(f"Failed to connect: {e}")

    # create, read, update, delete, close
    def create(self, data):
        """
        Inserts a single document into the animals collection.
        """
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as e:
                print(f"Insert failed: {e}")
                return False
        else:
            print("Data parameter is empty - nothing to insert")
            return False

    def read(self, criteria=None):
        """
        Queries the animals collection and returns matching documents as a list.
        """
        try:
            if criteria is None or not isinstance(criteria, dict):
                cursor = self.collection.find({})
            else:
                cursor = self.collection.find(criteria)
            return list(cursor)
        except PyMongoError as e:
            print(f"Query failed: {e}")
            return []

    def update(self, criteria, update_data):
        """
        Updates one or more documents matching the criteria.
        """
        if not isinstance(criteria, dict) or not isinstance(update_data, dict):
            print("Criteria and update_data must both be dictionaries")
            return 0
        try:
            result = self.collection.update_many(criteria, update_data)
            return result.modified_count
        except PyMongoError as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, criteria):
        """
        Deletes documents matching the given criteria.
        """
        if not isinstance(criteria, dict):
            print("Criteria must be a dictionary")
            return 0
        try:
            result = self.collection.delete_many(criteria)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete failed: {e}")
            return 0

    def close(self):
        """Closes the MongoDB connection when done."""
        if self.client:
            self.client.close()
            print("MongoDB connection closed")