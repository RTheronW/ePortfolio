# Enhancement notes — Artifact Three

Author: Richard T. Walker  
Course: CS 499 Milestone Four  
Artifact: CS 340 Grazioso Salvare

This file maps each code-review finding to the change that closed it.

1. Hardcoded database password in `CRUD_Python_Module.py` — constructor reads `AAC_USERNAME` and `AAC_PASSWORD`; no password default remains in the file
2. Hardcoded password in the notebook setup cell — notebook passes `os.environ.get(...)` into `AnimalShelter`
3. `read()` always materialized the full result — optional `limit` argument; table still uses `read()`, analytics do not
4. No index helper — `ensure_indexes()` on the four filter fields plus `rescue_filter`
5. Analytics only in pandas `value_counts` — `aggregate()` and `rescue_analytics()` run `$match` / `$facet` in MongoDB
6. Dashboard had no summary for trainers or leadership — `stats-panel` shows candidate count, average age, and top breeds
7. Map drew a marker for every Reset row — selected row, or a 25-row window
8. `update()` forwarded a raw dict with no `$set` — `_as_update_document`
9. Empty update or delete criteria could touch the whole collection — both methods refuse `{}`
10. Tests never covered the data layer — `tests/test_animal_shelter.py`
11. Connection defaults hid missing secrets — constructor raises `ValueError` when user or password is absent
