# CRUD and analytics for the Grazioso Salvare animals collection.
# CS 340 original: create, read, update, delete against aac.animals.
# CS 499 enhancement: environment credentials, indexes, aggregation,
# optional read limit, and $set-safe updates.
#
# Author: Richard T. Walker
# Course: CS 499 Milestone Four — Databases

import os

try:
    from pymongo.errors import PyMongoError
except ImportError:  # lets unit tests run without pymongo installed
    class PyMongoError(Exception):
        pass


class AnimalShelter(object):
    """
    Data layer for the aac.animals collection.

    Constructor credentials come from arguments or environment variables.
    There is no password default in this file.
    Pass collection= to inject a stand-in for tests.
    """

    ENV_USER = "AAC_USERNAME"
    ENV_PASS = "AAC_PASSWORD"
    ENV_HOST = "AAC_HOST"
    ENV_PORT = "AAC_PORT"
    ENV_DB = "AAC_DB"
    ENV_COL = "AAC_COLLECTION"

    INDEX_FIELDS = (
        "animal_type",
        "breed",
        "sex_upon_outcome",
        "age_upon_outcome_in_weeks",
    )

    def __init__(self, username=None, password=None, collection=None,
                 host=None, port=None, database=None, col_name=None):
        if collection is not None:
            self.client = None
            self.database = None
            self.collection = collection
            return

        user = username or os.environ.get(self.ENV_USER)
        password = password or os.environ.get(self.ENV_PASS)
        host = host or os.environ.get(self.ENV_HOST, "localhost")
        port = int(port or os.environ.get(self.ENV_PORT, "27017"))
        db_name = database or os.environ.get(self.ENV_DB, "aac")
        col_name = col_name or os.environ.get(self.ENV_COL, "animals")

        if not user or not password:
            raise ValueError(
                "MongoDB credentials are missing. Set "
                f"{self.ENV_USER} and {self.ENV_PASS}, or pass username "
                "and password to AnimalShelter()."
            )

        try:
            from pymongo import MongoClient
            self.client = MongoClient(
                f"mongodb://{user}:{password}@{host}:{port}/?authSource=admin"
            )
            self.database = self.client[db_name]
            self.collection = self.database[col_name]
            self.client.admin.command("ping")
            print("MongoDB connection established successfully")
        except Exception as e:
            raise Exception(f"Failed to connect: {e}")

    def create(self, data):
        """Insert one document. Returns True if Mongo acknowledged the write."""
        if data is None or not isinstance(data, dict) or not data:
            print("Data parameter is empty - nothing to insert")
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Insert failed: {e}")
            return False

    def read(self, criteria=None, limit=None):
        """
        Return matching documents as a list.

        criteria: Mongo filter dict. Missing or non-dict values become {}.
        limit: optional cap so a caller can avoid materializing the
        whole collection when only a window is needed.
        """
        try:
            query = criteria if isinstance(criteria, dict) else {}
            cursor = self.collection.find(query)
            if limit is not None:
                cursor = cursor.limit(int(limit))
            return list(cursor)
        except PyMongoError as e:
            print(f"Query failed: {e}")
            return []

    def update(self, criteria, update_data):
        """
        Update documents that match criteria.

        If update_data has no Mongo operator key (does not start with $),
        it is wrapped in $set so a raw field dict cannot replace the
        whole document.
        """
        if not isinstance(criteria, dict) or not isinstance(update_data, dict):
            print("Criteria and update_data must both be dictionaries")
            return 0
        if not criteria:
            print("Refusing update with empty criteria")
            return 0
        try:
            payload = self._as_update_document(update_data)
            result = self.collection.update_many(criteria, payload)
            return result.modified_count
        except PyMongoError as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, criteria):
        """Delete documents that match criteria. Empty criteria is refused."""
        if not isinstance(criteria, dict):
            print("Criteria must be a dictionary")
            return 0
        if not criteria:
            print("Refusing delete with empty criteria")
            return 0
        try:
            result = self.collection.delete_many(criteria)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete failed: {e}")
            return 0

    def aggregate(self, pipeline):
        """Run a MongoDB aggregation pipeline and return the documents."""
        if not isinstance(pipeline, list) or not pipeline:
            print("Pipeline must be a non-empty list")
            return []
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as e:
            print(f"Aggregation failed: {e}")
            return []

    def ensure_indexes(self):
        """
        Create indexes on the fields used by the rescue-type filters.

        Single-field indexes cover each predicate. The compound index
        matches the common animal_type + sex + age + breed filter.
        """
        created = []
        try:
            for field in self.INDEX_FIELDS:
                name = self.collection.create_index(field)
                created.append(name)
            compound = self.collection.create_index(
                [
                    ("animal_type", 1),
                    ("sex_upon_outcome", 1),
                    ("age_upon_outcome_in_weeks", 1),
                    ("breed", 1),
                ],
                name="rescue_filter",
            )
            created.append(compound)
            return created
        except PyMongoError as e:
            print(f"Index creation failed: {e}")
            return created

    def rescue_analytics(self, criteria=None, top_n=5):
        """
        Compute candidate count, average age in weeks, and top breeds
        in MongoDB. One $facet pipeline so the dashboard does not pull
        the matching documents into pandas just to count them.
        """
        match = criteria if isinstance(criteria, dict) else {}
        limit = max(1, int(top_n))
        pipeline = []
        if match:
            pipeline.append({"$match": match})
        pipeline.append({
            "$facet": {
                "summary": [
                    {
                        "$group": {
                            "_id": None,
                            "candidate_count": {"$sum": 1},
                            "avg_age_weeks": {
                                "$avg": "$age_upon_outcome_in_weeks"
                            },
                        }
                    }
                ],
                "top_breeds": [
                    {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
                    {"$sort": {"count": -1}},
                    {"$limit": limit},
                ],
            }
        })

        rows = self.aggregate(pipeline)
        empty = {
            "candidate_count": 0,
            "avg_age_weeks": 0.0,
            "top_breeds": [],
        }
        if not rows:
            return empty

        facet = rows[0]
        summary_rows = facet.get("summary") or []
        if summary_rows:
            summary = summary_rows[0]
            count = int(summary.get("candidate_count") or 0)
            avg_age = summary.get("avg_age_weeks") or 0.0
        else:
            count = 0
            avg_age = 0.0

        breeds = []
        for item in facet.get("top_breeds") or []:
            breeds.append({
                "breed": item.get("_id") or "Unknown",
                "count": int(item.get("count") or 0),
            })

        return {
            "candidate_count": count,
            "avg_age_weeks": float(avg_age) if avg_age else 0.0,
            "top_breeds": breeds,
        }

    def close(self):
        """Close the MongoDB client when this instance opened one."""
        if self.client:
            self.client.close()
            print("MongoDB connection closed")

    @staticmethod
    def _as_update_document(update_data):
        """Wrap a raw field dict in $set. Leave operator documents alone."""
        if any(str(key).startswith("$") for key in update_data):
            return update_data
        return {"$set": update_data}
