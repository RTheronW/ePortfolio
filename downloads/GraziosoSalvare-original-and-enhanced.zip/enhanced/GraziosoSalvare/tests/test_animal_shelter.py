# Unit tests for the enhanced AnimalShelter data layer.
# Uses an in-memory stand-in collection so MongoDB is not required.
#
# Author: Richard T. Walker
# Course: CS 499 Milestone Four — Databases

import os
import sys
import unittest
from unittest.mock import MagicMock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from CRUD_Python_Module import AnimalShelter


class FakeResult:
    def __init__(self, acknowledged=True, modified_count=0, deleted_count=0):
        self.acknowledged = acknowledged
        self.modified_count = modified_count
        self.deleted_count = deleted_count


class FakeCollection:
    """Minimal collection that records calls and returns canned values."""

    def __init__(self):
        self.inserted = []
        self.find_calls = []
        self.update_calls = []
        self.delete_calls = []
        self.aggregate_calls = []
        self.index_calls = []
        self.find_docs = []
        self.aggregate_docs = []
        self.modified_count = 1
        self.deleted_count = 1

    def insert_one(self, data):
        self.inserted.append(data)
        return FakeResult(acknowledged=True)

    def find(self, query):
        self.find_calls.append(query)
        cursor = MagicMock()
        cursor.limit.side_effect = lambda n: self.find_docs[:n]
        cursor.__iter__.side_effect = lambda: iter(self.find_docs)
        return cursor

    def update_many(self, criteria, payload):
        self.update_calls.append((criteria, payload))
        return FakeResult(modified_count=self.modified_count)

    def delete_many(self, criteria):
        self.delete_calls.append(criteria)
        return FakeResult(deleted_count=self.deleted_count)

    def aggregate(self, pipeline):
        self.aggregate_calls.append(pipeline)
        return list(self.aggregate_docs)

    def create_index(self, spec, name=None):
        self.index_calls.append((spec, name))
        return name or str(spec)


class AnimalShelterTests(unittest.TestCase):
    def setUp(self):
        self.collection = FakeCollection()
        self.shelter = AnimalShelter(collection=self.collection)

    def test_constructor_rejects_missing_credentials(self):
        saved = {
            AnimalShelter.ENV_USER: os.environ.pop(AnimalShelter.ENV_USER, None),
            AnimalShelter.ENV_PASS: os.environ.pop(AnimalShelter.ENV_PASS, None),
        }
        try:
            with self.assertRaises(ValueError):
                AnimalShelter()
        finally:
            for key, value in saved.items():
                if value is not None:
                    os.environ[key] = value

    def test_create_rejects_empty_payload(self):
        self.assertFalse(self.shelter.create(None))
        self.assertFalse(self.shelter.create({}))
        self.assertEqual(self.collection.inserted, [])

    def test_create_inserts_document(self):
        self.assertTrue(self.shelter.create({"breed": "Bloodhound"}))
        self.assertEqual(self.collection.inserted[0]["breed"], "Bloodhound")

    def test_read_uses_empty_filter_when_criteria_missing(self):
        self.collection.find_docs = [{"animal_id": "A1"}]
        rows = self.shelter.read()
        self.assertEqual(self.collection.find_calls[0], {})
        self.assertEqual(rows[0]["animal_id"], "A1")

    def test_read_applies_limit(self):
        self.collection.find_docs = [{"n": 1}, {"n": 2}, {"n": 3}]
        rows = self.shelter.read({"animal_type": "Dog"}, limit=2)
        self.assertEqual(self.collection.find_calls[0], {"animal_type": "Dog"})
        self.assertEqual(len(rows), 2)

    def test_update_wraps_raw_fields_in_set(self):
        changed = self.shelter.update({"animal_id": "A1"}, {"name": "Rex"})
        self.assertEqual(changed, 1)
        criteria, payload = self.collection.update_calls[0]
        self.assertEqual(criteria, {"animal_id": "A1"})
        self.assertEqual(payload, {"$set": {"name": "Rex"}})

    def test_update_leaves_operator_document_alone(self):
        self.shelter.update({"animal_id": "A1"}, {"$inc": {"age": 1}})
        _, payload = self.collection.update_calls[0]
        self.assertEqual(payload, {"$inc": {"age": 1}})

    def test_update_refuses_empty_criteria(self):
        self.assertEqual(self.shelter.update({}, {"name": "Rex"}), 0)
        self.assertEqual(self.collection.update_calls, [])

    def test_delete_refuses_empty_criteria(self):
        self.assertEqual(self.shelter.delete({}), 0)
        self.assertEqual(self.collection.delete_calls, [])

    def test_delete_passes_criteria(self):
        self.assertEqual(self.shelter.delete({"animal_id": "A1"}), 1)
        self.assertEqual(self.collection.delete_calls[0], {"animal_id": "A1"})

    def test_ensure_indexes_covers_filter_fields(self):
        names = self.shelter.ensure_indexes()
        fields = [call[0] for call in self.collection.index_calls]
        for field in AnimalShelter.INDEX_FIELDS:
            self.assertIn(field, fields)
        compound_names = [call[1] for call in self.collection.index_calls]
        self.assertIn("rescue_filter", compound_names)
        self.assertTrue(names)

    def test_rescue_analytics_builds_match_and_facet(self):
        self.collection.aggregate_docs = [{
            "summary": [{"_id": None, "candidate_count": 4, "avg_age_weeks": 52.0}],
            "top_breeds": [{"_id": "Bloodhound", "count": 3}, {"_id": "Rottweiler", "count": 1}],
        }]
        query = {"animal_type": "Dog", "sex_upon_outcome": "Intact Male"}
        stats = self.shelter.rescue_analytics(query, top_n=2)

        pipeline = self.collection.aggregate_calls[0]
        self.assertEqual(pipeline[0], {"$match": query})
        self.assertIn("$facet", pipeline[1])
        self.assertEqual(stats["candidate_count"], 4)
        self.assertEqual(stats["avg_age_weeks"], 52.0)
        self.assertEqual(stats["top_breeds"][0]["breed"], "Bloodhound")
        self.assertEqual(stats["top_breeds"][0]["count"], 3)

    def test_rescue_analytics_empty_result(self):
        self.collection.aggregate_docs = []
        stats = self.shelter.rescue_analytics({})
        self.assertEqual(stats["candidate_count"], 0)
        self.assertEqual(stats["top_breeds"], [])

    def test_as_update_document(self):
        self.assertEqual(
            AnimalShelter._as_update_document({"color": "black"}),
            {"$set": {"color": "black"}},
        )
        raw = {"$set": {"color": "black"}}
        self.assertEqual(AnimalShelter._as_update_document(raw), raw)


if __name__ == "__main__":
    unittest.main()
