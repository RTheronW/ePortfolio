# CS 499 Artifact Three — Grazioso Salvare (enhanced)

Author: Richard T. Walker  
Original course: CS 340 (February 2026)  
Enhancement: CS 499 Milestone Four, Databases

## What this project is

A MongoDB-backed animal-shelter tool for Grazioso Salvare. `CRUD_Python_Module.py` is the data layer against the `aac.animals` collection. `ProjectTwoDashboard.ipynb` is the staff dashboard: Water Rescue, Mountain/Wilderness Rescue, Disaster/Tracking, and Reset filters, a pageable table, a breed pie chart, and a Leaflet map.

The CS 340 version already connected to MongoDB and implemented CRUD. The constructor stored a database password in source. `read()` always returned a full Python list. Breed counts and the map ran in the browser after that list was loaded. `update()` forwarded the caller's dict with no `$set` guard.

## What changed in CS 499

- Credentials come from `AAC_USERNAME` and `AAC_PASSWORD`. There is no password in the source.
- `ensure_indexes()` creates single-field indexes on `animal_type`, `breed`, `sex_upon_outcome`, and `age_upon_outcome_in_weeks`, plus a `rescue_filter` compound index.
- `aggregate()` runs a pipeline. `rescue_analytics()` uses `$match` and `$facet` to return candidate count, average age in weeks, and top breeds without pulling those documents into pandas.
- The dashboard stats panel displays those MongoDB results when a rescue filter is applied.
- `read()` still feeds the table. It now accepts an optional `limit`.
- `update()` wraps a raw field dict in `$set`. Empty update and delete criteria are refused.
- The map uses the selected row, or at most 25 results, so Reset does not draw a pin for every imported animal.
- Unit tests cover credentials, `$set`, empty-criteria guards, index creation, and the analytics pipeline shape.

## How to run

Requires Python 3, MongoDB with the Austin Animal Center collection loaded as `aac.animals`, and the packages in `requirements.txt`.

```bash
export AAC_USERNAME=aacuser
export AAC_PASSWORD='your-local-password'
pip install -r requirements.txt
python3 -m unittest tests/test_animal_shelter.py
```

Open `ProjectTwoDashboard.ipynb` in Jupyter and run the cells. The notebook reads the same environment variables. Copy `.env.example` if you want a local checklist; do not put a real password in git.

## Files

- `CRUD_Python_Module.py` — CRUD, indexes, aggregation
- `ProjectTwoDashboard.ipynb` — Dash dashboard with stats panel
- `tests/test_animal_shelter.py` — unit tests with a fake collection
- `.env.example` — environment variable names
- `ENHANCEMENT_NOTES.md` — code-review findings mapped to files
