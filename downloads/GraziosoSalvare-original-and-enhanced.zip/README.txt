CS 499 Milestone Four — Enhancement Three: Databases
Student: Richard T. Walker
Artifact: CS 340 Grazioso Salvare Animal Shelter

This archive contains:

  original/CS 340 7-1 - Project Two_Walker, Richard T
      Unmodified CS 340 CRUD module and Dash notebook.

  enhanced/GraziosoSalvare
      CS 499 enhanced source with environment credentials, MongoDB
      indexes, aggregation analytics, a dashboard stats panel, a
      capped map, safer updates, unit tests, README, and notes.

Submit the narrative Word document separately:
  CS 499 Milestone Four Narrative_Walker Richard.docx
