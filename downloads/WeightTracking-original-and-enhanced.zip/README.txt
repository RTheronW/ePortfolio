CS 499 Milestone Two — Enhancement One: Software Design and Engineering
Student: Richard T. Walker
Artifact: CS 360 Weight Tracking Android application

This archive contains:

  original/WeightTrackingProject_WalkerRichard
      Unmodified CS 360 source (caches removed).

  enhanced/WeightTrackingProject_WalkerRichard
      CS 499 enhanced source with password hashing, per-user isolation,
      a repository layer, schema migration, date entry, progress header,
      file headers, unit tests, and README.

Submit the narrative Word document separately:
  CS 499 Milestone Two Narrative_Walker Richard.docx
