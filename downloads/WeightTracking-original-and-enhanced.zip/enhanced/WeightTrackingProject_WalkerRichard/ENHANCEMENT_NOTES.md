# Enhancement notes — Artifact One

Author: Richard T. Walker
Course: CS 499 Milestone Two
Artifact: CS 360 Weight Tracking Android application

This file is a short companion to README.md. It lists the code-review findings and the file that closed each one.

1. Plain-text passwords — PasswordHasher.java, User.java, LoginActivity.java
2. No user id on the login Intent — LoginActivity.EXTRA_USER_ID
3. Weight table shared by every account — WeightEntry.userId, WeightDao.getEntriesForUser
4. Device-wide goal in SharedPreferences — User.goalWeight
5. Room on the UI thread — WeightRepository and removal of allowMainThreadQueries
6. Destructive schema upgrades — AppDatabase.MIGRATION_2_3
7. Dates fixed to today — editTextDate on the main screen
8. Zero and negative weights accepted — InputValidator.isPositiveWeight
9. Repeated empty-field checks — InputValidator
10. Thin documentation — file headers, README.md, this file
11. Hidden delete ImageButton — removed from list_item_weight.xml
12. Adapter nested in MainActivity — WeightAdapter.java
13. allowBackup while credentials were plain — AndroidManifest allowBackup=false
14. Hard-coded SMS number in two classes — SmsConstants.DEMO_DESTINATION
