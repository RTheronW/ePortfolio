/**
 * File: WeightRepository.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Keep Activities off the Room API and off the main thread.
 * All DAO calls run on a single background executor. Results are
 * posted back on the caller's callback so the UI thread only binds
 * views.
 */
package com.example.weighttrackingproject_walkerrichard;

import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeightRepository {

    public interface ResultCallback<T> {
        void onResult(T result);
    }

    private final UserDao userDao;
    private final WeightDao weightDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public WeightRepository(AppDatabase database) {
        this.userDao = database.userDao();
        this.weightDao = database.weightDao();
    }

    public void findUserByUsername(String username, ResultCallback<User> callback) {
        executor.execute(() -> post(callback, userDao.findByUsername(username)));
    }

    public void findUserById(int userId, ResultCallback<User> callback) {
        executor.execute(() -> post(callback, userDao.findById(userId)));
    }

    public void insertUser(User user, ResultCallback<Long> callback) {
        executor.execute(() -> post(callback, userDao.insert(user)));
    }

    public void updateUser(User user, ResultCallback<Void> callback) {
        executor.execute(() -> {
            userDao.update(user);
            post(callback, null);
        });
    }

    public void getEntriesForUser(int userId, ResultCallback<List<WeightEntry>> callback) {
        executor.execute(() -> post(callback, weightDao.getEntriesForUser(userId)));
    }

    public void getLatestForUser(int userId, ResultCallback<WeightEntry> callback) {
        executor.execute(() -> post(callback, weightDao.getLatestForUser(userId)));
    }

    public void insertWeight(WeightEntry entry, ResultCallback<Void> callback) {
        executor.execute(() -> {
            weightDao.insert(entry);
            post(callback, null);
        });
    }

    public void updateWeight(WeightEntry entry, ResultCallback<Void> callback) {
        executor.execute(() -> {
            weightDao.update(entry);
            post(callback, null);
        });
    }

    public void deleteWeight(WeightEntry entry, ResultCallback<Void> callback) {
        executor.execute(() -> {
            weightDao.delete(entry);
            post(callback, null);
        });
    }

    private <T> void post(ResultCallback<T> callback, T value) {
        if (callback == null) {
            return;
        }
        mainHandler.post(() -> callback.onResult(value));
    }
}
