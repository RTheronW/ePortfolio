/**
 * File: SmsConstants.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Give the demo SMS destination one name so MainActivity and
 * NotificationsActivity do not each hard-code 555-1234. The destination
 * itself is not the Category One enhancement.
 */
package com.example.weighttrackingproject_walkerrichard;

public final class SmsConstants {

    public static final String DEMO_DESTINATION = "5551234";

    private SmsConstants() {
        // Utility class.
    }
}
