/**
 * File: User.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Room entity for one account. The password column now holds a
 * salted PBKDF2 hash, not a usable password. goalWeight lives on the
 * user row so two accounts on one device do not share a target.
 */
package com.example.weighttrackingproject_walkerrichard;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "users",
        indices = {@Index(value = {"username"}, unique = true)}
)
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String username;

    /**
     * Salted hash in saltHex:hashHex form. Column name stays "password"
     * so a version-2 database can keep its existing column.
     */
    @ColumnInfo(name = "password")
    public String passwordHash;

    public double goalWeight;

    public User(String username, String passwordHash) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.goalWeight = 0.0;
    }
}
