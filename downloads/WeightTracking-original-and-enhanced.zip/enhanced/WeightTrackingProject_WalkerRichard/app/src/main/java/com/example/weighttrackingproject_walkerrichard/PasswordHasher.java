/**
 * File: PasswordHasher.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Keep a usable password out of the users table. The original
 * CS 360 artifact stored the typed password as plain text. This helper
 * derives a PBKDF2 hash with a per-account salt and verifies a typed
 * password against that stored value.
 *
 * Stored format:  saltHex:hashHex
 * Legacy rows that have no colon are treated as plain text so an
 * existing local database can be upgraded on the next successful login
 * instead of being wiped.
 */
package com.example.weighttrackingproject_walkerrichard;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordHasher {

    private static final String ALGORITHM_PREFERRED = "PBKDF2WithHmacSHA256";
    private static final String ALGORITHM_FALLBACK = "PBKDF2WithHmacSHA1";
    private static final int ITERATIONS = 12000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final int SALT_BYTES = 16;

    private PasswordHasher() {
        // Utility class.
    }

    /**
     * Derives a salted hash for a new or updated password.
     */
    public static String hash(String password) {
        if (password == null) {
            throw new IllegalArgumentException("Password cannot be null");
        }
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] digest = pbkdf2(password, salt);
        return toHex(salt) + ":" + toHex(digest);
    }

    /**
     * Returns true when the typed password matches the stored credential.
     * Supports both the salted-hash format and a leftover plain-text row.
     */
    public static boolean verify(String typedPassword, String stored) {
        if (typedPassword == null || stored == null || stored.isEmpty()) {
            return false;
        }
        if (!isHashed(stored)) {
            return typedPassword.equals(stored);
        }
        String[] parts = stored.split(":");
        if (parts.length != 2) {
            return false;
        }
        byte[] salt = fromHex(parts[0]);
        byte[] expected = fromHex(parts[1]);
        byte[] actual = pbkdf2(typedPassword, salt);
        return MessageDigest.isEqual(expected, actual);
    }

    /**
     * True when the stored value already uses salt:hash encoding.
     */
    public static boolean isHashed(String stored) {
        return stored != null && stored.contains(":");
    }

    private static byte[] pbkdf2(String password, byte[] salt) {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS);
            SecretKeyFactory factory;
            try {
                factory = SecretKeyFactory.getInstance(ALGORITHM_PREFERRED);
            } catch (Exception ignored) {
                // API 24-25 devices do not provide PBKDF2WithHmacSHA256.
                factory = SecretKeyFactory.getInstance(ALGORITHM_FALLBACK);
            }
            return factory.generateSecret(spec).getEncoded();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to derive password hash", e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            builder.append(String.format("%02x", value));
        }
        return builder.toString();
    }

    private static byte[] fromHex(String hex) {
        int length = hex.length();
        byte[] data = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
