/**
 * File: WeightDao.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Create, read, update, and delete weight rows for one user.
 * Every list and latest-row query takes a userId so the main screen
 * cannot load another account's health data.
 */
package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {

    @Insert
    void insert(WeightEntry entry);

    @Update
    void update(WeightEntry entry);

    @Delete
    void delete(WeightEntry entry);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY date DESC, id DESC")
    List<WeightEntry> getEntriesForUser(int userId);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY date DESC, id DESC LIMIT 1")
    WeightEntry getLatestForUser(int userId);
}
