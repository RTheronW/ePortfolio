/**
 * File: LoginActivity.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Establish identity before any weight data is shown. Create
 * account hashes the password before insert. Login loads the user by
 * username, verifies the hash, and puts the authenticated user id on
 * the Intent that opens MainActivity.
 */
package com.example.weighttrackingproject_walkerrichard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "com.example.weighttrackingproject_walkerrichard.USER_ID";

    private EditText editTextUsername;
    private EditText editTextPassword;
    private EditText editTextConfirmPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private WeightRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        repository = new WeightRepository(AppDatabase.getDatabase(this));

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString();

        String error = InputValidator.validateCredentials(username, password);
        if (error != null) {
            toast(error);
            return;
        }

        setButtonsEnabled(false);
        repository.findUserByUsername(username, user -> {
            setButtonsEnabled(true);
            if (user == null || !PasswordHasher.verify(password, user.passwordHash)) {
                toast("Invalid username or password");
                return;
            }
            if (!PasswordHasher.isHashed(user.passwordHash)) {
                user.passwordHash = PasswordHasher.hash(password);
                repository.updateUser(user, ignored -> openMain(user.id));
            } else {
                openMain(user.id);
            }
        });
    }

    private void attemptCreateAccount() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString();
        String confirm = editTextConfirmPassword.getText().toString();

        String error = InputValidator.validateNewAccount(username, password, confirm);
        if (error != null) {
            toast(error);
            return;
        }

        setButtonsEnabled(false);
        repository.findUserByUsername(username, existing -> {
            if (existing != null) {
                setButtonsEnabled(true);
                toast("Username already exists. Please choose another.");
                return;
            }
            User created = new User(username, PasswordHasher.hash(password));
            repository.insertUser(created, ignored -> {
                setButtonsEnabled(true);
                editTextPassword.setText("");
                editTextConfirmPassword.setText("");
                toast("Account created successfully. You can now log in.");
            });
        });
    }

    private void openMain(int userId) {
        toast("Login successful");
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        startActivity(intent);
        finish();
    }

    private void setButtonsEnabled(boolean enabled) {
        buttonLogin.setEnabled(enabled);
        buttonCreateAccount.setEnabled(enabled);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
