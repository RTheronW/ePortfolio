/**
 * File: WeightAdapter.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: List adapter extracted from MainActivity so the history
 * screen is not also responsible for row binding. Short tap edits.
 * Long press deletes. The leftover hidden delete button is gone.
 */
package com.example.weighttrackingproject_walkerrichard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    public interface WeightActionListener {
        void onEdit(WeightEntry entry);

        void onDelete(WeightEntry entry);
    }

    private final List<WeightEntry> entries = new ArrayList<>();
    private final WeightActionListener listener;

    public WeightAdapter(WeightActionListener listener) {
        this.listener = listener;
    }

    public void submitList(List<WeightEntry> updated) {
        entries.clear();
        if (updated != null) {
            entries.addAll(updated);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_weight, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);
        holder.textViewDate.setText(entry.date);
        holder.textViewWeight.setText(String.format(Locale.getDefault(), "%.1f lbs", entry.weight));
        holder.itemView.setOnClickListener(v -> listener.onEdit(entry));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onDelete(entry);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView textViewDate;
        final TextView textViewWeight;

        ViewHolder(View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewWeight = itemView.findViewById(R.id.textViewWeight);
        }
    }
}
