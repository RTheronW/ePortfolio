/**
 * File: MainActivity.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: History screen for one signed-in account. The screen now
 * requires a user id from LoginActivity, loads only that user's rows,
 * stores the goal on the user record, lets the user set a date, and
 * shows current weight, goal, and remaining difference in a header
 * that does not require opening the database.
 */
package com.example.weighttrackingproject_walkerrichard;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements WeightAdapter.WeightActionListener {

    private RecyclerView recyclerViewWeights;
    private EditText editTextWeight;
    private EditText editTextDate;
    private Button buttonAddWeight;
    private Button buttonNotifications;
    private Button buttonSetGoal;
    private Button buttonLogout;
    private TextView tvGoalWeight;
    private TextView tvCurrentWeight;
    private TextView tvProgress;

    private WeightAdapter adapter;
    private WeightRepository repository;

    private int currentUserId = -1;
    private User currentUser;
    private double goalWeight = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        currentUserId = getIntent().getIntExtra(LoginActivity.EXTRA_USER_ID, -1);
        if (currentUserId <= 0) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        repository = new WeightRepository(AppDatabase.getDatabase(this));

        recyclerViewWeights = findViewById(R.id.recyclerViewWeights);
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextDate = findViewById(R.id.editTextDate);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonNotifications = findViewById(R.id.buttonNotifications);
        buttonSetGoal = findViewById(R.id.buttonSetGoal);
        buttonLogout = findViewById(R.id.buttonLogout);
        tvGoalWeight = findViewById(R.id.tvGoalWeight);
        tvCurrentWeight = findViewById(R.id.tvCurrentWeight);
        tvProgress = findViewById(R.id.tvProgress);

        editTextDate.setText(today());

        recyclerViewWeights.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter(this);
        recyclerViewWeights.setAdapter(adapter);

        buttonAddWeight.setOnClickListener(v -> addNewWeight());
        buttonSetGoal.setOnClickListener(v -> showSetGoalDialog());
        buttonNotifications.setOnClickListener(v ->
                startActivity(new Intent(this, NotificationsActivity.class)));
        buttonLogout.setOnClickListener(v -> logout());

        loadSignedInUser();
    }

    private void loadSignedInUser() {
        repository.findUserById(currentUserId, user -> {
            if (user == null) {
                toast("Session expired. Please log in again.");
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                return;
            }
            currentUser = user;
            goalWeight = user.goalWeight;
            updateGoalDisplay();
            loadDataFromDatabase();
        });
    }

    private void loadDataFromDatabase() {
        repository.getEntriesForUser(currentUserId, entries -> {
            adapter.submitList(entries);
            updateProgressHeader(entries);
        });
    }

    private void addNewWeight() {
        String weightStr = editTextWeight.getText().toString().trim();
        String dateStr = editTextDate.getText().toString().trim();

        if (weightStr.isEmpty()) {
            toast("Please enter a weight");
            return;
        }
        if (!InputValidator.isValidDate(dateStr)) {
            toast("Date must use yyyy-MM-dd");
            return;
        }

        try {
            double newWeight = Double.parseDouble(weightStr);
            if (!InputValidator.isPositiveWeight(newWeight)) {
                toast("Weight must be greater than zero");
                return;
            }

            WeightEntry newEntry = new WeightEntry(currentUserId, dateStr, newWeight);
            repository.insertWeight(newEntry, ignored -> {
                loadDataFromDatabase();
                editTextWeight.setText("");
                editTextDate.setText(today());
                checkGoalAchievement(newWeight);
                toast("Weight added successfully");
            });
        } catch (NumberFormatException e) {
            toast("Invalid weight");
        }
    }

    @Override
    public void onEdit(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight");

        final EditText input = new EditText(this);
        input.setText(String.valueOf(entry.weight));
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newWeightStr = input.getText().toString().trim();
            if (newWeightStr.isEmpty()) {
                return;
            }
            try {
                double updated = Double.parseDouble(newWeightStr);
                if (!InputValidator.isPositiveWeight(updated)) {
                    toast("Weight must be greater than zero");
                    return;
                }
                entry.weight = updated;
                repository.updateWeight(entry, ignored -> {
                    loadDataFromDatabase();
                    toast("Weight updated successfully");
                });
            } catch (NumberFormatException e) {
                toast("Invalid weight");
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public void onDelete(WeightEntry entry) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage("Delete weight from " + entry.date + "?")
                .setPositiveButton("Delete", (dialog, which) ->
                        repository.deleteWeight(entry, ignored -> loadDataFromDatabase()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void checkGoalAchievement(double newWeight) {
        if (goalWeight <= 0) {
            return;
        }
        if (newWeight <= goalWeight) {
            String message = "Congratulations! You have reached your goal weight of "
                    + goalWeight + " lbs.";
            toast(message);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSms(message);
            } else {
                toast("SMS permission not granted. Goal reached notification skipped.");
            }
        }
    }

    private void sendGoalReachedSms(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(SmsConstants.DEMO_DESTINATION, null, message, null, null);
            toast("SMS notification sent");
        } catch (Exception e) {
            toast("Failed to send SMS notification");
        }
    }

    private void updateGoalDisplay() {
        if (goalWeight > 0) {
            tvGoalWeight.setText(formatPounds(goalWeight));
        } else {
            tvGoalWeight.setText("--- lbs");
        }
    }

    private void updateProgressHeader(List<WeightEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            tvCurrentWeight.setText("--- lbs");
            tvProgress.setText("Add a weight to see progress toward your goal.");
            return;
        }
        double current = entries.get(0).weight;
        tvCurrentWeight.setText(formatPounds(current));
        if (goalWeight <= 0) {
            tvProgress.setText("Set a goal to track remaining weight.");
        } else if (current <= goalWeight) {
            tvProgress.setText("At or below goal. Difference: "
                    + formatPounds(goalWeight - current));
        } else {
            tvProgress.setText("Remaining to goal: " + formatPounds(current - goalWeight));
        }
    }

    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight (lbs)");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goalStr = input.getText().toString().trim();
            if (goalStr.isEmpty()) {
                return;
            }
            try {
                double parsed = Double.parseDouble(goalStr);
                if (!InputValidator.isPositiveWeight(parsed)) {
                    toast("Goal must be greater than zero");
                    return;
                }
                goalWeight = parsed;
                if (currentUser != null) {
                    currentUser.goalWeight = goalWeight;
                    repository.updateUser(currentUser, ignored -> {
                        updateGoalDisplay();
                        loadDataFromDatabase();
                        toast("Goal weight updated");
                    });
                }
            } catch (NumberFormatException e) {
                toast("Invalid number");
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void logout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    private String formatPounds(double value) {
        return String.format(Locale.getDefault(), "%.1f lbs", value);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
