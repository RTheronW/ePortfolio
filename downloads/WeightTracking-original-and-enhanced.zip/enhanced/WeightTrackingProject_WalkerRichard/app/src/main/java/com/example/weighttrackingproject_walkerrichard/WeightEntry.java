/**
 * File: WeightEntry.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Room entity for one history row. userId ties the row to the
 * signed-in account so accounts on the same device do not share a
 * history list. Date stays text in yyyy-MM-dd form so the user can
 * backfill a day other than today.
 */
package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "weight_entries",
        indices = {@Index(value = {"userId"})}
)
public class WeightEntry {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int userId;
    public String date;
    public double weight;

    public WeightEntry(int userId, String date, double weight) {
        this.userId = userId;
        this.date = date;
        this.weight = weight;
    }
}
