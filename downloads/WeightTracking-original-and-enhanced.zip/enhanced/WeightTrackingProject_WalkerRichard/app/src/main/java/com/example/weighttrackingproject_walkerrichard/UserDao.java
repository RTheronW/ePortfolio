/**
 * File: UserDao.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Data-access methods for the users table. The original
 * username-and-password login query is gone because a salted hash
 * cannot be matched inside SQL. Lookup is by username only. Hash
 * comparison happens in application code.
 */
package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserDao {

    @Insert
    long insert(User user);

    @Update
    void update(User user);

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User findByUsername(String username);

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    User findById(int id);
}
