/**
 * File: InputValidator.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: One place for the login, create-account, weight, and date
 * rules so Activities do not copy the same empty-field checks.
 */
package com.example.weighttrackingproject_walkerrichard;

import java.util.regex.Pattern;

public final class InputValidator {

    public static final int MIN_USERNAME_LENGTH = 3;
    public static final int MIN_PASSWORD_LENGTH = 8;

    private static final Pattern DATE_PATTERN = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");

    private InputValidator() {
        // Utility class.
    }

    public static String validateCredentials(String username, String password) {
        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return "Please enter both username and password";
        }
        if (username.trim().length() < MIN_USERNAME_LENGTH) {
            return "Username must be at least " + MIN_USERNAME_LENGTH + " characters";
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            return "Password must be at least " + MIN_PASSWORD_LENGTH + " characters";
        }
        return null;
    }

    public static String validateNewAccount(String username, String password, String confirmPassword) {
        String base = validateCredentials(username, password);
        if (base != null) {
            return base;
        }
        if (confirmPassword == null || !password.equals(confirmPassword)) {
            return "Password and confirmation do not match";
        }
        return null;
    }

    public static boolean isPositiveWeight(double weight) {
        return weight > 0.0;
    }

    public static boolean isValidDate(String date) {
        return date != null && DATE_PATTERN.matcher(date.trim()).matches();
    }
}
