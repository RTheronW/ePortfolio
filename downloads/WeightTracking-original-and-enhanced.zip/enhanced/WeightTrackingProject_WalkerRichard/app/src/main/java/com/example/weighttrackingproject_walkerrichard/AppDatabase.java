/**
 * File: AppDatabase.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Single Room database for accounts and weight history.
 * Version 3 adds goalWeight on users and userId on weight_entries.
 * Main-thread queries and destructive migration are removed so the
 * UI thread stays free and an upgrade does not wipe local data.
 */
package com.example.weighttrackingproject_walkerrichard;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {User.class, WeightEntry.class}, version = 3, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UserDao userDao();

    public abstract WeightDao weightDao();

    private static volatile AppDatabase INSTANCE;

    /**
     * Adds the columns required for per-user goals and history without
     * dropping the existing tables.
     */
    static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE users ADD COLUMN goalWeight REAL NOT NULL DEFAULT 0.0");
            database.execSQL("ALTER TABLE weight_entries ADD COLUMN userId INTEGER NOT NULL DEFAULT 0");
            database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_users_username ON users(username)");
            database.execSQL("CREATE INDEX IF NOT EXISTS index_weight_entries_userId ON weight_entries(userId)");
        }
    };

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "weight_tracker_db")
                            .addMigrations(MIGRATION_2_3)
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
