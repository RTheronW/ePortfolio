/**
 * File: ExampleUnitTest.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Keep the default host-side smoke test so the test source set
 * still builds if a reviewer runs the generated example.
 */
package com.example.weighttrackingproject_walkerrichard;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}
