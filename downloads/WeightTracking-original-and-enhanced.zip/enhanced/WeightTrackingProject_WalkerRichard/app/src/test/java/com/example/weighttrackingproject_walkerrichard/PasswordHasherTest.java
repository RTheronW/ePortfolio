/**
 * File: PasswordHasherTest.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Prove that hashing is not reversible in the test, that the
 * same password verifies, and that a wrong password fails. These tests
 * run on the JVM and do not need an emulator.
 */
package com.example.weighttrackingproject_walkerrichard;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class PasswordHasherTest {

    @Test
    public void hashIsNotThePlainPassword() {
        String stored = PasswordHasher.hash("Secret123");
        assertTrue(PasswordHasher.isHashed(stored));
        assertNotEquals("Secret123", stored);
    }

    @Test
    public void samePasswordVerifies() {
        String stored = PasswordHasher.hash("Secret123");
        assertTrue(PasswordHasher.verify("Secret123", stored));
    }

    @Test
    public void wrongPasswordFails() {
        String stored = PasswordHasher.hash("Secret123");
        assertFalse(PasswordHasher.verify("WrongPass", stored));
    }

    @Test
    public void twoHashesOfSamePasswordDifferBecauseOfSalt() {
        String first = PasswordHasher.hash("Secret123");
        String second = PasswordHasher.hash("Secret123");
        assertNotEquals(first, second);
        assertTrue(PasswordHasher.verify("Secret123", first));
        assertTrue(PasswordHasher.verify("Secret123", second));
    }

    @Test
    public void legacyPlainTextStillVerifiesThenCanBeDetected() {
        assertFalse(PasswordHasher.isHashed("Secret123"));
        assertTrue(PasswordHasher.verify("Secret123", "Secret123"));
        assertFalse(PasswordHasher.verify("other", "Secret123"));
    }
}
