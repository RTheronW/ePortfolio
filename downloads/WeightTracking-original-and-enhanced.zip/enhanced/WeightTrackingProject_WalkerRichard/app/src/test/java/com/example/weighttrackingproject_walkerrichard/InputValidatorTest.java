/**
 * File: InputValidatorTest.java
 * Author: Richard T. Walker
 * Course: CS 499 Computer Science Capstone
 * Date: September 2026
 *
 * Intent: Cover the shared validation rules used by login and the
 * history screen so empty, short, mismatched, and non-positive values
 * are rejected in one place.
 */
package com.example.weighttrackingproject_walkerrichard;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class InputValidatorTest {

    @Test
    public void rejectsEmptyCredentials() {
        assertNotNull(InputValidator.validateCredentials("", "password1"));
        assertNotNull(InputValidator.validateCredentials("user", ""));
    }

    @Test
    public void rejectsShortUsernameAndPassword() {
        assertNotNull(InputValidator.validateCredentials("ab", "password1"));
        assertNotNull(InputValidator.validateCredentials("user", "short"));
    }

    @Test
    public void acceptsLegalCredentials() {
        assertNull(InputValidator.validateCredentials("walker", "password1"));
    }

    @Test
    public void createAccountRequiresMatchingConfirmation() {
        assertNotNull(InputValidator.validateNewAccount("walker", "password1", "password2"));
        assertNull(InputValidator.validateNewAccount("walker", "password1", "password1"));
    }

    @Test
    public void weightMustBePositive() {
        assertFalse(InputValidator.isPositiveWeight(0));
        assertFalse(InputValidator.isPositiveWeight(-1.5));
        assertTrue(InputValidator.isPositiveWeight(180.2));
    }

    @Test
    public void dateMustBeIsoFormat() {
        assertTrue(InputValidator.isValidDate("2026-09-16"));
        assertFalse(InputValidator.isValidDate("09/16/2026"));
        assertFalse(InputValidator.isValidDate(""));
    }
}
