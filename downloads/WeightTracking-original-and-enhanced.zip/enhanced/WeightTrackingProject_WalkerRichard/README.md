# Weight Tracking Android App — CS 499 Enhancement One

**Student:** Richard T. Walker
**Source course:** CS 360 (Mobile Architect and Programming)
**Capstone category:** Software Design and Engineering
**Date:** September 2026

## What this project is

A multi-screen Java Android application. A person can create an account, sign in, record weight over time, set a goal weight, and optionally receive a text when that goal is reached. Storage is Room (SQLite) with a users table and a weight-entries table.

The original CS 360 project already met that assignment. This repository folder is the CS 499 enhanced version used for Milestone Two.

## What changed in the enhancement

| Area | Original behavior | Enhanced behavior |
| --- | --- | --- |
| Credentials | Password stored as typed text | PBKDF2-HMAC-SHA256 hash with a per-account salt |
| Session | Login opened MainActivity with no user id | Authenticated `userId` is passed on the Intent |
| History | `getAllEntries()` returned every row | Queries filter on `userId` |
| Goal | One SharedPreferences value for the device | `goalWeight` stored on the signed-in user row |
| Threads | `allowMainThreadQueries()` | `WeightRepository` runs DAO calls on a background executor |
| Schema upgrades | `fallbackToDestructiveMigration()` | Explicit `MIGRATION_2_3` adds columns and indexes |
| Dates | Always stamped as today | User-editable `yyyy-MM-dd` field |
| Input | Empty check only | Shared validator: length, confirm password, weight > 0 |
| UI | Goal label only; hidden delete button | Progress header (current, goal, remaining); adapter extracted |
| Backup | `allowBackup="true"` while passwords were plain text | `allowBackup="false"` |
| Tests | Default example test | `PasswordHasherTest` and `InputValidatorTest` |

SMS destination `5551234` is a named constant only. That number is not claimed as the enhancement.

## How to run

1. Open the enhanced project in Android Studio.
2. Sync Gradle and run on an API 24+ emulator or device.
3. Create an account (password at least 8 characters, confirmation required).
4. Add weights, set a goal, and confirm the header updates.
5. Create a second account on the same emulator and confirm histories stay separate.

Host-side unit tests:

```text
./gradlew test
```

Room DAO tests are not included as instrumented tests because they need an emulator. Hashing and validation are covered on the JVM.

## File map

- `PasswordHasher.java` — salted PBKDF2 helper
- `InputValidator.java` — shared field rules
- `WeightRepository.java` — background Room access
- `User.java` / `UserDao.java` — account entity and username lookup
- `WeightEntry.java` / `WeightDao.java` — per-user history
- `AppDatabase.java` — version 3 and migration
- `LoginActivity.java` — hash, verify, pass user id
- `MainActivity.java` — session, date, progress header
- `WeightAdapter.java` — list binding extracted from MainActivity
- `SmsConstants.java` — shared demo destination

## Security notes before public posting

Do not publish a database file that still contains leftover plain-text passwords from a pre-enhancement install. After the first successful login on a legacy row, the app rehashes that password. New accounts never store the typed password.
