package com.example.weighttrackingproject_walkerrichard;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private AppDatabase database;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initialize database
        database = AppDatabase.getDatabase(this);
        userDao = database.userDao();

        // Login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this,
                            "Please enter both username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check credentials in database
                User user = userDao.login(username, password);

                if (user != null) {
                    Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this,
                            "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Create Account button
        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this,
                            "Please enter both username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if username already exists
                if (userDao.checkIfUserExists(username) != null) {
                    Toast.makeText(LoginActivity.this,
                            "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create new user
                User newUser = new User(username, password);
                userDao.insert(newUser);

                Toast.makeText(LoginActivity.this,
                        "Account created successfully! You can now login.", Toast.LENGTH_LONG).show();

                // Clear password field for security
                editTextPassword.setText("");
            }
        });
    }
}