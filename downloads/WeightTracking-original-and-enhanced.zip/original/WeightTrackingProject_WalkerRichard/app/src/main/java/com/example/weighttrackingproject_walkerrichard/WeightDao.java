package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {

    @Insert
    void insert(WeightEntry entry);

    @Update
    void update(WeightEntry entry);

    @Delete
    void delete(WeightEntry entry);

    @Query("SELECT * FROM weight_entries ORDER BY date DESC")
    List<WeightEntry> getAllEntries();

    @Query("SELECT * FROM weight_entries WHERE id = :id LIMIT 1")
    WeightEntry getEntryById(int id);
}