package com.example.weighttrackingproject_walkerrichard;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class NotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private TextView textViewStatus;
    private Button buttonRequestPermission;
    private Button buttonSendTest;
    private Button buttonBackToMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notifications);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewStatus = findViewById(R.id.textViewStatus);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSendTest = findViewById(R.id.buttonSendTest);
        buttonBackToMain = findViewById(R.id.buttonBackToMain);

        checkSmsPermission();

        // Request permission button
        buttonRequestPermission.setOnClickListener(v -> requestSmsPermission());

        // Send test notification button
        buttonSendTest.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendTestSms();
            } else {
                Toast.makeText(this, "Permission required to send SMS", Toast.LENGTH_SHORT).show();
            }
        });

        // Back to Main button
        buttonBackToMain.setOnClickListener(v -> {
            finish();   // Closes this screen and returns to MainActivity
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textViewStatus.setText("✅ Permission GRANTED\nYou will receive weight goal notifications via SMS.");
            textViewStatus.setTextColor(getColor(android.R.color.holo_green_dark));
            buttonRequestPermission.setEnabled(false);
            buttonSendTest.setEnabled(true);
        } else {
            textViewStatus.setText("❌ Permission NOT GRANTED\nNotifications are currently disabled.");
            textViewStatus.setTextColor(getColor(android.R.color.holo_red_dark));
            buttonRequestPermission.setEnabled(true);
            buttonSendTest.setEnabled(false);
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            checkSmsPermission();   // Refresh status after permission response
        }
    }

    private void sendTestSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("555-1234", null,
                    "✅ Test: Your weight goal has been reached!", null, null);
            Toast.makeText(this, "Test SMS sent successfully!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send test SMS", Toast.LENGTH_SHORT).show();
        }
    }
}