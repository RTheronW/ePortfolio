package com.example.weighttrackingproject_walkerrichard;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewWeights;
    private EditText editTextWeight;
    private Button buttonAddWeight;
    private Button buttonNotifications;
    private Button buttonSetGoal;
    private Button buttonLogout;

    private TextView tvGoalWeight;

    private WeightAdapter adapter;
    private List<WeightEntry> weightList = new ArrayList<>();

    private AppDatabase database;
    private WeightDao weightDao;

    private SharedPreferences preferences;
    private static final String PREF_GOAL_WEIGHT = "goal_weight";
    private double goalWeight = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        database = AppDatabase.getDatabase(this);
        weightDao = database.weightDao();

        recyclerViewWeights = findViewById(R.id.recyclerViewWeights);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonNotifications = findViewById(R.id.buttonNotifications);
        buttonSetGoal = findViewById(R.id.buttonSetGoal);
        buttonLogout = findViewById(R.id.buttonLogout);
        tvGoalWeight = findViewById(R.id.tvGoalWeight);

        preferences = getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);
        goalWeight = preferences.getFloat(PREF_GOAL_WEIGHT, 0.0f);

        recyclerViewWeights.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter();
        recyclerViewWeights.setAdapter(adapter);

        loadDataFromDatabase();
        updateGoalDisplay();

        buttonAddWeight.setOnClickListener(v -> addNewWeight());
        buttonSetGoal.setOnClickListener(v -> showSetGoalDialog());
        buttonNotifications.setOnClickListener(v -> {
            startActivity(new Intent(this, NotificationsActivity.class));
        });
        buttonLogout.setOnClickListener(v -> logout());
    }

    private void loadDataFromDatabase() {
        weightList.clear();
        weightList.addAll(weightDao.getAllEntries());
        adapter.notifyDataSetChanged();
    }

    private void addNewWeight() {
        String weightStr = editTextWeight.getText().toString().trim();
        if (weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double newWeight = Double.parseDouble(weightStr);
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            WeightEntry newEntry = new WeightEntry(today, newWeight);
            weightDao.insert(newEntry);

            loadDataFromDatabase();
            editTextWeight.setText("");

            // Check if goal is reached
            checkGoalAchievement(newWeight);

            Toast.makeText(this, "Weight added successfully", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateWeight(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight");

        final EditText input = new EditText(this);
        input.setText(String.valueOf(entry.weight));
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newWeightStr = input.getText().toString().trim();
            if (!newWeightStr.isEmpty()) {
                try {
                    entry.weight = Double.parseDouble(newWeightStr);
                    weightDao.update(entry);
                    loadDataFromDatabase();
                    Toast.makeText(this, "Weight updated successfully", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void checkGoalAchievement(double newWeight) {
        if (goalWeight <= 0) return;

        if (newWeight <= goalWeight) {
            String message = "Congratulations! You have reached your goal weight of " + goalWeight + " lbs!";

            Toast.makeText(this, message, Toast.LENGTH_LONG).show();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSms(message);
            } else {
                Toast.makeText(this, "SMS permission not granted. Goal reached notification skipped.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendGoalReachedSms(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("555-1234", null, message, null, null);
            Toast.makeText(this, "SMS notification sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS notification", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateGoalDisplay() {
        if (goalWeight > 0) {
            tvGoalWeight.setText(goalWeight + " lbs");
        } else {
            tvGoalWeight.setText("--- lbs");
        }
    }

    private void showSetGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight (lbs)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goalStr = input.getText().toString().trim();
            if (!goalStr.isEmpty()) {
                try {
                    goalWeight = Double.parseDouble(goalStr);
                    preferences.edit().putFloat(PREF_GOAL_WEIGHT, (float) goalWeight).apply();
                    updateGoalDisplay();
                    Toast.makeText(this, "Goal weight updated", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void logout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ====================== Adapter ======================
    private class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_weight, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            WeightEntry entry = weightList.get(position);
            holder.textViewDate.setText(entry.date);
            holder.textViewWeight.setText(entry.weight + " lbs");

            // Short tap = Edit
            holder.itemView.setOnClickListener(v -> updateWeight(entry));

            // Long press = Delete with confirmation
            holder.itemView.setOnLongClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Entry")
                        .setMessage("Delete weight from " + entry.date + "?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            weightDao.delete(entry);
                            loadDataFromDatabase();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return weightList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView textViewDate, textViewWeight;
            ImageButton buttonDelete;

            ViewHolder(View itemView) {
                super(itemView);
                textViewDate = itemView.findViewById(R.id.textViewDate);
                textViewWeight = itemView.findViewById(R.id.textViewWeight);
                buttonDelete = itemView.findViewById(R.id.buttonDelete);
                buttonDelete.setVisibility(View.GONE);
            }
        }
    }
}