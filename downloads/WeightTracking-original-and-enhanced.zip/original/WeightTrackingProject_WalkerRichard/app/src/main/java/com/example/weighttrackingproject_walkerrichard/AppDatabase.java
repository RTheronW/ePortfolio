package com.example.weighttrackingproject_walkerrichard;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, WeightEntry.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract WeightDao weightDao();     // ← New

    private static AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "weight_tracker_db")
                            .allowMainThreadQueries()   // For learning purposes
                            .fallbackToDestructiveMigration()  // Allows version changes
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}