package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String username;
    public String password;   // In a real app, you should hash this!

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}