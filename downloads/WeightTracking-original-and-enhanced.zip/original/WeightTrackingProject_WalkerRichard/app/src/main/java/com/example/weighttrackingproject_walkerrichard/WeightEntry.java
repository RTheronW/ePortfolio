package com.example.weighttrackingproject_walkerrichard;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "weight_entries")
public class WeightEntry {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String date;        // Stored as String (yyyy-MM-dd)
    public double weight;

    public WeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }
}