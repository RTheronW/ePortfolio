This folder is the original CS 360 Weight Tracking project source as submitted
before the CS 499 software-design enhancement. Build caches (.gradle, .idea)
were removed so the archive stays small. Application source, layouts, and
Gradle files are unchanged from the CS 360 artifact.
